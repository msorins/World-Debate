-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: admin_world-debate
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bug_report`
--

DROP TABLE IF EXISTS `bug_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_report` (
  `logs_description` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report`
--

LOCK TABLES `bug_report` WRITE;
/*!40000 ALTER TABLE `bug_report` DISABLE KEYS */;
INSERT INTO `bug_report` VALUES ('test'),('da'),('nu'),('nu'),('nu');
/*!40000 ALTER TABLE `bug_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `logs_count` int(11) NOT NULL AUTO_INCREMENT,
  `logs_date` varchar(15) NOT NULL,
  `logs_user_name` varchar(64) NOT NULL,
  `logs_message` varchar(100) NOT NULL,
  `logs_post_name` varchar(64) NOT NULL,
  `logs_post_count` int(11) NOT NULL,
  PRIMARY KEY (`logs_count`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (36,'2014-01-04','sorynsoo','Received 10 Debate Points ','Game Debate',50),(37,'2014-01-04','Seby','Received 3 Debate Points ','Game Debate',50),(16,'2014-01-02','VillaMan97','Received 3 Debate Points ','Dogs vs Cats',39),(15,'2014-01-02','Annabiro','Received 3 Debate Points ','LaL',2),(14,'2014-01-02','sorynsoo','Received 3 Debate Points ','LaL',2),(13,'2014-01-02','sorynsoo','Received 10 Debate Points ','LaL',2),(10,'2014-01-01','sorynsoo','Received 10 Debate Points ','Vlog Bosses',42),(11,'2014-01-01','Seby','Received 3 Debate Points ','Vlog Bosses',42),(12,'2014-01-01','sorynsoo','Received 3 Debate Points ','Vlog Bosses',42),(38,'2014-01-04','sorynsoo','You gained 1achievement','',0),(35,'2014-01-04','VillaMan97','Received 3 Debate Points ','2 Cars',41),(34,'2014-01-04','EAGame','Received 3 Debate Points ','2 Cars',41),(33,'2014-01-04','sorynsoo','Received 3 Debate Points ','2 Cars',41),(32,'2014-01-03','Liviu','Received 3 Debate Points ','Prostia romaneasca',43),(31,'2014-01-03','sorynsoo','Received 3 Debate Points ','Prostia romaneasca',43),(30,'2014-01-03','Seby','Received 3 Debate Points ','Prostia romaneasca',43),(29,'2014-01-03','Seby','Received 10 Debate Points ','Prostia romaneasca',43),(39,'2014-01-07','Annabiro','Received 10 Debate Points ','Random debate about making debates',35),(40,'2014-01-07','Annabiro','Received 3 Debate Points ','Random debate about making debates',35),(41,'2014-01-07','sorynsoo','Received 3 Debate Points ','Random debate about making debates',35),(42,'2014-01-07','Seby','Received 3 Debate Points ','Cola VS Pepsi',56),(43,'2014-01-07','VillaMan97','Received 3 Debate Points ','Cola VS Pepsi',56),(44,'2014-01-09','Seby','Received 10 Debate Points ','MTA CHALLENGE',55),(45,'2014-01-09','Seby','Received 3 Debate Points ','MTA CHALLENGE',55),(46,'2014-01-09','Eddu','Received 3 Debate Points ','MTA CHALLENGE',55),(47,'2014-01-09','Silver','Received 3 Debate Points ','MTA CHALLENGE',55),(48,'2014-01-09','Seby','Received 10 Debate Points ','El Shaarawy',44),(49,'2014-01-09','Seby','Received 3 Debate Points ','El Shaarawy',44),(50,'2014-01-09','VillaMan97','Received 3 Debate Points ','El Shaarawy',44),(51,'2014-01-09','Liviu','Received 3 Debate Points ','El Shaarawy',44),(52,'2014-01-09','Silver','Received 3 Debate Points ','El Shaarawy',44),(53,'2014-01-09','Seby','Received 3 Debate Points ','Doge sau Lil Bub',47),(54,'2014-01-09','Liviu','Received 3 Debate Points ','Doge sau Lil Bub',47),(55,'2014-01-09','pawn','Received 3 Debate Points ','Doge sau Lil Bub',47),(56,'2014-01-09','Silver','Received 3 Debate Points ','Doge sau Lil Bub',47),(57,'2014-01-09','Roby','Received 3 Debate Points ','NFS vs Fast and Furious',58),(58,'2014-01-09','sorynsoo','Received 3 Debate Points ','NFS vs Fast and Furious',58),(59,'2014-01-09','Seby','Received 3 Debate Points ','NFS vs Fast and Furious',58),(60,'2014-01-09','Silver','Received 3 Debate Points ','Windows VS Linux',59),(61,'2014-01-09','Roby','Received 3 Debate Points ','Windows VS Linux',59),(62,'2014-01-09','sorynsoo','Received 3 Debate Points ','Windows VS Linux',59),(63,'2014-01-09','Seby','Received 3 Debate Points ','Windows VS Linux',59),(64,'2014-01-09','Liviu','Received 3 Debate Points ','Windows VS Linux',59),(65,'2014-01-09','Silver','Received 3 Debate Points ','Yahoo VS Skype',60),(66,'2014-01-09','Roby','Received 3 Debate Points ','Yahoo VS Skype',60),(67,'2014-01-09','Seby','Received 3 Debate Points ','Yahoo VS Skype',60),(68,'2014-01-09','Liviu','Received 3 Debate Points ','Yahoo VS Skype',60),(69,'2014-01-09','Silver','Received 3 Debate Points ','Sprite VS Fanta',61),(70,'2014-01-09','Roby','Received 3 Debate Points ','Sprite VS Fanta',61),(71,'2014-01-09','Seby','Received 3 Debate Points ','Sprite VS Fanta',61),(72,'2014-01-09','Liviu','Received 3 Debate Points ','Sprite VS Fanta',61),(73,'2014-01-09','sorynsoo','Received 10 Debate Points ','OS BATTLE',67),(74,'2014-01-09','sorynsoo','Received 3 Debate Points ','OS BATTLE',67),(75,'2014-01-09','Liviu','Received 3 Debate Points ','OS BATTLE',67),(76,'2014-01-09','Eddu','You gained 1 achievement','OS BATTLE',67),(77,'2014-01-10','sorynsoo','Received 3 Debate Points ','Populars games',52),(78,'2014-01-10','Seby','Received 3 Debate Points ','Populars games',52),(79,'2014-01-10','pawn','Received 3 Debate Points ','Populars games',52),(80,'2014-01-12','VillaMan97','Received 3 Debate Points ','Telefonie',54),(81,'2014-01-12','pawn','Received 3 Debate Points ','Telefonie',54),(82,'2014-01-12','sorynsoo','Received 3 Debate Points ','Telefonie',54),(83,'2014-01-12','Eremia123','Received 3 Debate Points ','Telefonie',54),(84,'2014-01-12','Seby','Received 3 Debate Points ','Telefonie',54),(85,'2014-01-12','Silver','Received 3 Debate Points ','Telefonie',54),(86,'2014-01-13','','Received 10 Debate Points ','Music',68),(87,'2014-01-28','sorynsoo','Received 10 Debate Points ','Color Battle',70),(88,'2014-01-28','sorynsoo','Received 3 Debate Points ','Color Battle',70),(89,'2014-01-28','Seby','Received 3 Debate Points ','Color Battle',70),(90,'2014-01-28','Andreea','You gained 1 achievement','Color Battle',70),(91,'2014-01-29','sorynsoo','Received 10 Debate Points ','Romana sau Mate',71),(92,'2014-01-29','Seby','Received 3 Debate Points ','Romana sau Mate',71),(93,'2014-01-31','sorynsoo','Received 3 Debate Points ','Two Big Cites',36),(94,'2014-01-31','Annaabiro','Received 3 Debate Points ','Two Big Cites',36),(95,'2014-01-31','sorynsoo','Received 3 Debate Points ','Dota 2 Vs LoL',37),(96,'2014-01-31','pawn','Received 3 Debate Points ','Dota 2 Vs LoL',37),(97,'2014-02-02','VillaMan97','Received 3 Debate Points ','Creeatii',48),(98,'2014-02-02','sorynsoo','Received 3 Debate Points ','Creeatii',48),(99,'2014-02-02','Eddu','Received 3 Debate Points ','Creeatii',48),(100,'2014-04-13','','Received 10 Debate Points ','Tech Battle',75),(101,'2014-04-17','Mitza','Received 10 Debate Points ','Microsoft vs Intel',76),(102,'2014-04-17','sorynsoo','Received 3 Debate Points ','Microsoft vs Intel',76),(103,'2014-04-17','Mitza','You gained 1 achievement','Microsoft vs Intel',76),(104,'2014-05-11','','Received 10 Debate Points ','Cel mai bun tesen animat',78),(105,'2014-05-15','','Received 10 Debate Points ','Sports Battle',79),(106,'2015-07-17','sorynsoo','Received 10 Debate Points ','Samsung vs LG',81),(107,'2015-07-17','sorynsoo','Received 3 Debate Points ','Samsung vs LG',81),(108,'2015-07-17','sorynsoo2','You gained 1 achievement','Samsung vs LG',81),(109,'2015-07-30','','Received 10 Debate Points ','Best Soda',80);
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_posts`
--

DROP TABLE IF EXISTS `public_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `public_posts` (
  `post_count` int(11) NOT NULL AUTO_INCREMENT,
  `post_owner` varchar(64) NOT NULL,
  `post_title` varchar(64) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `post_category` varchar(255) NOT NULL,
  `post_description1` varchar(200) NOT NULL,
  `post_description2` varchar(200) DEFAULT NULL,
  `post_image1` varchar(255) NOT NULL,
  `post_image2` varchar(255) NOT NULL,
  `post_video1` varchar(100) NOT NULL,
  `post_video2` varchar(100) NOT NULL,
  `post_competitive` int(2) NOT NULL,
  `post_expire` varchar(61) NOT NULL,
  `post_anonymus` int(2) NOT NULL,
  `post_likes1` int(11) NOT NULL,
  `post_likes2` int(11) NOT NULL,
  `post_type` varchar(20) NOT NULL,
  `post_target` varchar(64) DEFAULT NULL,
  `post_activate` int(11) NOT NULL DEFAULT '2',
  `post_is_expired` int(11) NOT NULL DEFAULT '2',
  `post_winner` int(11) NOT NULL,
  `post_who_voted1` varchar(5000) NOT NULL DEFAULT '#0#',
  `post_who_voted2` varchar(5000) NOT NULL DEFAULT '#0#',
  `post_with` varchar(20) NOT NULL,
  PRIMARY KEY (`post_count`),
  UNIQUE KEY `post_title` (`post_title`),
  KEY `post_id` (`post_owner`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_posts`
--

LOCK TABLES `public_posts` WRITE;
/*!40000 ALTER TABLE `public_posts` DISABLE KEYS */;
INSERT INTO `public_posts` VALUES (2,'sorynsoo','LaL','2013-12-25 15:23:36','art','fraiere','fffff','LaL1.jpeg','LaL2.jpeg','','',2,'2014-01-01',2,1,3,'competitive','sorynsoo',1,1,2,'#0#1#','#0#1#5#',''),(34,'sorynsoo','Gta 4 Or Gta 5','2013-12-30 14:12:57','Games','Gta  4 Review','Gta 5 Review','Gta 4 Or Gta 5','Gta 4 Or Gta 5','http://www.youtube.com/embed/svETP_DDgUc','http://www.youtube.com/embed/L94bxLL2Ol0',2,'2013-12-29',2,1,2,'competitive','sorynsoo',1,1,1,'#0#1#','#0#9#17#','videos'),(4,'sorynsoo','s','2013-12-26 18:03:42','art','s','s','s','s','','',1,'2013-12-27',2,0,0,'solo','',2,2,0,'#0#','#0#',''),(5,'sorynsoo','aa','2013-12-26 18:26:18','art','aa','aa','aa','aa','','',1,'2013-12-27',2,0,0,'solo','',2,2,0,'#0#','#0#',''),(6,'sorynsoo','ss','2013-12-26 18:26:22','art','ss','ss','ss','ss','','',1,'2013-12-27',2,0,0,'solo','',2,2,0,'#0#','#0#',''),(8,'sorynsoo','h','2013-12-26 18:43:00','art','h','','h','','','',1,'1',2,0,0,'competitive','h',2,2,0,'#0#','#0#',''),(9,'sorynsoo','Marry Christmas','2013-12-26 19:18:03','art','Sarbatoareeee','Tot mai tare e asta','Marry Christmas1.jpeg','Marry Christmas2.jpeg','','',2,'2013-12-27',2,0,0,'competitive','sorynsoo',1,1,0,'#0#','#0#',''),(10,'sorynsoo','Test','2013-12-26 19:20:55','art','dadada','nununu','Test1.jpeg','Test2.jpeg','','',2,'2013-12-26',1,9,5,'solo','',1,1,1,'#0##########','#0#####1#',''),(11,'sorynsoo','Test2','2013-12-26 19:23:51','art','Lamborghini ?','Sau Mosul?','Test21.jpeg','Test22.jpeg','','',2,'2013-12-29',2,2,0,'solo','',1,1,1,'#0##1#','#0#',''),(18,'sorynsoo','Zupar Supar','2013-12-28 13:11:25','art','Hanoy Tower','da','Zupar Supar1.jpeg','Zupar Supar2.jpeg','','',2,'2013-12-29',2,0,1,'practice','sorynsoo',1,1,2,'#0#','#0#1#',''),(16,'sorynsoo','Lala','2013-12-27 20:26:34','art','DA','DA','Lala1.jpeg','Lala2.jpeg','','',2,'2013-12-28',1,1,0,'solo','',1,1,1,'#0#1#','#0#',''),(51,'Seby','Desene Animate Cartoon Network','2014-01-02 13:02:35','Drawn or Cartoons','Tom and Jerry','Ed, Edd and Eddy','Desene Animate Cartoon Network1.jpeg','Desene Animate Cartoon Network2.jpeg','','',2,'2014-01-03',2,1,1,'solo','',1,1,0,'#0#17#','#0#14#','picture'),(31,'sorynsoo','Chuck Norris Debate','2013-12-29 15:46:47','art','Video-ul zice totul','Chuck Norris shows JC van Damme how to do a proper','Chuck Norris Debate','Chuck Norris Debate','http://www.youtube.com/embed/VsabFEisZ2Y','http://www.youtube.com/embed/qcqPmjAkK3Q',2,'2013-12-29',2,1,1,'competitive','sorynsoo',1,1,1,'#0#1#','#0#5#','videos'),(30,'sorynsoo','zatzat','2013-12-29 14:26:35','art','adadad','adadadad','zatzat1.jpeg','zatzat2.jpeg','','',2,'2013-12-30',2,0,0,'practice','sorynsoo',1,1,0,'#0#','#0#','picture'),(29,'sorynsoo','Cars','2013-12-29 09:07:03','Auto and Vehicules','da','nu','Cars','Cars','http://www.youtube.com/embed/xh5-NseodyE','http://www.youtube.com/embed/i81NKr4xIHo',2,'2013-12-28',2,1,0,'solo','',1,1,1,'#0#1#','#0#','videos'),(35,'Annabiro','Random debate about making debates','2013-12-30 14:29:04','Others','Hehe','Brasov related','Random debate about making debates1.jpeg','Random debate about making debates2.jpeg','','',2,'2014-01-06',2,2,0,'competitive','sorynsoo',1,1,1,'#0#5#1#','#0#','picture'),(36,'sorynsoo','Two Big Cites','2013-12-30 19:22:40','art','New York Landscape','Chicago Landscape','Two Big Cites1.jpeg','Two Big Cites2.jpeg','','',2,'2014-01-30',2,2,0,'solo','',1,1,1,'#0#1#22#','#0#','picture'),(37,'sorynsoo','Dota 2 Vs LoL','2013-12-30 20:08:07','Games','Dota2 : http://blog.dota2.com/','League of Legends: http://eune.leagueoflegends.com/','Dota 2 Vs LoL','Dota 2 Vs LoL','http://www.youtube.com/embed/5MuZmHEGqXQ','http://www.youtube.com/embed/pSmc4C1KXrs',2,'2014-01-30',2,2,0,'solo','',1,1,1,'#0#1#17#','#0#','videos'),(55,'sorynsoo','MTA CHALLENGE','2014-01-05 09:41:12','Games','Multi Theft Auto','San Andreas MultiPlayer','MTA CHALLENGE','MTA CHALLENGE','http://www.youtube.com/embed/ILaAvaIF1kg','http://www.youtube.com/embed/of4EPFzLMO4',2,'2014-01-08',2,1,3,'competitive','Seby',1,1,2,'#0#1#','#0#9#14#24#','videos'),(56,'sorynsoo','Cola VS Pepsi','2014-01-05 16:13:25','Others','Cola','Pepsi','Cola VS Pepsi1.jpeg','Cola VS Pepsi2.jpeg','','',2,'2014-01-06',2,2,1,'solo','',1,1,1,'#0#9#15#','#0#1#','picture'),(43,'Piki','Prostia romaneasca','2014-01-01 15:01:31','Comedy','http://www.youtube.com/watch?v=UFE9lWKrOd0','De ce esti fan Paul Walker?','Prostia romaneasca','Prostia romaneasca','http://www.youtube.com/embed/UFE9lWKrOd0','http://www.youtube.com/embed/nIkIKBDnLAI',2,'2014-01-02',2,0,3,'competitive','Seby',1,1,2,'#0#','#0#9#1#13#','videos'),(41,'Seby','2 Cars','2013-12-31 16:50:02','Auto and Vehicules','Nissan Skyline Fast and Furious','Dodge Charger Fast and Furious','2 Cars1.jpeg','2 Cars2.jpeg','','',2,'2014-01-03',2,1,3,'solo','',1,1,2,'#0#9#','#0#1#11#15#','picture'),(42,'sorynsoo','Vlog Bosses','2013-12-31 17:05:32','Others','Mikey Hash ','Satana','Vlog Bosses','Vlog Bosses','http://www.youtube.com/embed/xqZbnoTZ9po','http://www.youtube.com/embed/I-hzOt0Z-c0',2,'2013-12-31',2,4,2,'competitive','Seby',1,1,1,'#0#9#1#11#13#','#0#10#12#','videos'),(44,'Eddu','El Shaarawy','2014-01-01 15:59:46','Sports','Paine.','Messi.','El Shaarawy1.jpeg','El Shaarawy2.jpeg','','',2,'2014-01-08',2,2,4,'competitive','Seby',1,1,2,'#0#1#14#','#0#9#15#13#24#','picture'),(46,'sorynsoo','Tv Shows','2014-01-01 16:25:20','Others','Supernatural Rullz','','Tv Shows','','http://www.youtube.com/embed/rm_UcERAVw8','http://www.youtube.com/embed/',1,'1',2,0,0,'competitive','Eddu',2,2,0,'#0#','#0#','videos'),(54,'Liviu','Telefonie','2014-01-04 13:37:18','Others','Samsung','Apple','Telefonie1.jpeg','Telefonie2.jpeg','','',2,'2014-01-11',2,6,0,'solo','',1,1,1,'#0#15#17#1#19#9#24#','#0#','picture'),(47,'VillaMan97','Doge sau Lil Bub','2014-01-01 16:34:04','Comedy','Doge :3','Lil Bub &amp;lt;3','Doge sau Lil Bub1.jpeg','Doge sau Lil Bub2.jpeg','','',2,'2014-01-08',2,4,1,'solo','',1,1,1,'#0#9#13#17#24#','#0#21#','picture'),(48,'Roby','Creeatii','2014-01-01 16:40:06','art',':&amp;gt;',':&amp;gt;','Creeatii1.png','Creeatii2.png','','',2,'2014-02-01',2,1,3,'solo','',1,1,2,'#0#9#','#0#15#1#14#','picture'),(49,'VillaMan97','Facebook vs Google Plus','2014-01-01 18:51:16','Others','Facebook','Google+','Facebook vs Google Plus1.png','Facebook vs Google Plus2.jpeg','','',2,'2014-01-08',2,1,4,'practice','VillaMan97',1,1,2,'#0#1#','#0#10#9#13#24#','picture'),(50,'sorynsoo','Game Debate','2014-01-02 07:07:58','Games','I don&amp;#039;t think you can beat me :).','That&amp;#039;s right...','Game Debate','Game Debate','http://www.youtube.com/embed/L94bxLL2Ol0','http://www.youtube.com/embed/0yVXPWUHMqU',2,'2014-01-03',2,2,0,'competitive','Seby',1,1,1,'#0#9#1#','#0#','videos'),(52,'Liviu','Populars games','2014-01-02 17:23:15','Games','Assassins Creed 4 Black Flag','GTA 5','Populars games','Populars games','http://www.youtube.com/embed/R2EVWKn1HcQ','http://www.youtube.com/embed/QkkoHAzjnUs',2,'2014-01-09',2,0,3,'solo','',1,1,2,'#0#','#0#1#9#17#','videos'),(53,'VillaMan97','Paul Walker si Roxana Babenco','2014-01-02 20:17:15','Comedy','De ce esti fan Paul Walker','De ce esti fan Roxana Babenco','Paul Walker si Roxana Babenco','Paul Walker si Roxana Babenco','http://www.youtube.com/embed/nIkIKBDnLAI','http://www.youtube.com/embed/g0Kfd10-w7E',2,'',2,2,1,'practice','VillaMan97',1,1,1,'#0#1#24#','#0#14#','videos'),(57,'Silver','Silver vs Piki','2014-01-05 19:23:01','Games','Votati preferatul!','','Silver vs Piki1.jpeg','','','',1,'1',2,0,0,'competitive','Piki',2,2,0,'#0#','#0#','picture'),(58,'Silver','NFS vs Fast and Furious','2014-01-05 19:29:21','Auto and Vehicules','Need For Speed','Fast and Furios','NFS vs Fast and Furious1.jpeg','NFS vs Fast and Furious2.jpeg','','',2,'2014-01-08',2,1,3,'solo','',1,1,2,'#0#24#','#0#16#1#9#','picture'),(59,'Silver','Windows VS Linux','2014-01-05 19:35:11','Others','Windows','Linux','Windows VS Linux1.jpeg','Windows VS Linux2.jpeg','','',2,'2014-01-08',2,5,1,'solo','',1,1,1,'#0#24#16#1#9#13#','#0#32#','picture'),(60,'Silver','Yahoo VS Skype','2014-01-05 19:39:30','Others','Yahoo','Skype','Yahoo VS Skype1.jpeg','Yahoo VS Skype2.jpeg','','',2,'2014-01-08',2,4,1,'solo','',1,1,1,'#0#24#16#9#13#','#0#1#','picture'),(61,'Silver','Sprite VS Fanta','2014-01-05 19:43:23','Others','Sprite','Fanta','Sprite VS Fanta1.jpeg','Sprite VS Fanta2.jpeg','','',2,'2014-01-08',2,2,2,'solo','',1,1,1,'#0#24#16#','#0#1#9#','picture'),(67,'sorynsoo','OS BATTLE','2014-01-07 16:07:58','Others','Windows 7 Ultimate','Windows 8.1','OS BATTLE1.png','OS BATTLE2.png','','',2,'2014-01-08',2,2,1,'competitive','Seby',1,1,1,'#0#1#13#','#0#9#','picture'),(68,'sorynsoo','Music','2014-01-09 05:49:30','art','PSY - GANGNAM STYLE','Ylvis - The Fox (What Does the Fox Say?)','Music','Music','http://www.youtube.com/embed/9bZkp7q19f0','http://www.youtube.com/embed/jofNR_WkoCE',2,'2014-01-12',2,1,1,'competitive','JackOJack',1,1,0,'#0#9#','#0#32#','videos'),(70,'sorynsoo','Color Battle','2014-01-26 12:36:11','Others','Blue is the beeest','Red is the best! :))','Color Battle1.png','Color Battle2.png','','',2,'2014-01-27',2,2,1,'competitive','Andreea',1,1,1,'#0#1#9#','#0#32#','picture'),(71,'Seby','Romana sau Mate','2014-01-27 17:08:52','Others','Romana','Matematica','Romana sau Mate1.jpeg','Romana sau Mate2.jpeg','','',2,'2014-01-28',2,1,1,'competitive','sorynsoo',1,1,2,'#0#1#','#0#9#','picture'),(76,'Mitza','Microsoft vs Intel','2014-04-09 14:10:07','Others','Microsoft','Google','Microsoft vs Intel1.jpeg','Microsoft vs Intel2.jpeg','','',2,'2014-04-16',2,1,0,'competitive','sorynsoo',1,1,1,'#0#1#','#0#','picture'),(75,'alex','Tech Battle','2014-04-09 14:07:02','Others','Smartphone Samsung Galaxy S4','Tableta cu android','Tech Battle1.jpeg','Tech Battle2.jpeg','','',2,'2014-04-12',2,0,0,'competitive','sorynsoo',1,1,0,'#0#','#0#','picture'),(80,'Andrei','Best Soda','2014-05-11 10:02:52','Others','Pepsi ','Fanta','Best Soda1.png','Best Soda2.png','','',2,'2015-07-20',2,0,0,'competitive','sorynsoo',1,1,0,'#0#','#0#','picture'),(78,'sorynsoo','Cel mai bun tesen animat','2014-04-09 14:17:58','Drawn or Cartoons','Tom si Jerry','Familia Flintstone','Cel mai bun tesen animat','Cel mai bun tesen animat','http://www.youtube.com/embed/arupfeKWqLM','http://www.youtube.com/embed/7RaC4a9bqdg',2,'2014-05-10',2,0,0,'competitive','Mitza',1,1,0,'#0#','#0#','videos'),(79,'Andrei','Sports Battle','2014-05-11 10:01:34','Sports','Basket','Tenis','Sports Battle1.png','Sports Battle2.jpeg','','',2,'2014-05-14',2,0,0,'competitive','sorynsoo',1,1,0,'#0#','#0#','picture'),(81,'sorynsoo','Samsung vs LG','2015-07-13 18:45:07','Others','Samsuns S6 Edge','LG G4','Samsung vs LG1.jpeg','Samsung vs LG2.jpeg','','',2,'2015-07-16',2,1,0,'competitive','sorynsoo2',1,1,1,'#0#1#','#0#','picture');
/*!40000 ALTER TABLE `public_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'auto incrementing user_id of each user, unique index',
  `user_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s name',
  `user_password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s password in salted and hashed format',
  `user_email` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s email',
  `user_publicname` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_facebook` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_avatar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_voted` varchar(2000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#0#',
  `user_total_votes` int(11) NOT NULL,
  `user_good_votes` int(11) NOT NULL,
  `user_notifications` int(11) NOT NULL,
  `user_points` int(11) NOT NULL,
  `user_follows` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#0#',
  `user_number_followers` int(11) NOT NULL,
  `user_achievements` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#0#',
  `user_background` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='user data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'sorynsoo','$2y$10$9ndFVuRTTce6NY7vSeexZefTdZE6FGs9121bYk/6dS7zg5afB5UdS','sorynsoo@gmail.com','Sorin Soo','https://www.facebook.com/soryn.mircea2','Bla bla bla bla Bla bla bla blaBla bla bla blaBla bla bla blaBla bla bla blaBla bla bla blaBla bla ','1.jpeg','#0#1#2#10#11#16#14#13#12#17#18#29#22#31#34#35#36#37#41#38#42#44#43#48#49#52#53#50#54#55#56#58#59#60#61#67#70#76#71#81#',27,20,0,233,'#0#9#13#2#',2,'#0#2#3#4#5#1#',''),(2,'sorynsoo2','$2y$10$pA6Y6mYecDIMkac9DiS52eJuGGfJRunfJjBwC3J9a2o0.MlgkeYqC','sorynsoo2@gmail.com','','','','','#0#',1,0,0,0,'#0#',1,'#0#2#',''),(3,'DryanSeron','$2y$10$fDI/J/TpvTkJ1Z0XGdCYl.yzHXfcrnRZmQ590qfr2vLJT8eTC0eXi','razvirock@yahoo.com','','','','','#0#17#',1,1,1,3,'#0#',0,'#0#1#',''),(4,'test','$2y$10$Yhqb5rqhuumsJmVPLeVr/..tmbCpnLeOvzxTiVPJIKhbb99W0qYLO','test@gmail.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(5,'Annabiro','$2y$10$H7RD5UG500fIl613gh5gB.AhCnXL3T/Y2t9AhWwSwFvoSa3sYudK.','anna_biro@yahoo.com','','','','','#0#2#31#35#',2,2,0,16,'#0#',0,'#0#1#',''),(6,'JackOJack','$2y$10$3K50kyRLQ8kiYLeESL5Xmu9bIAiJQNZ2d2aoPhoLUsJY7uf1Xn9V2','sDada@gmail.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(7,'Bula','$2y$10$TJgCAguYhW1SpI9PzQ2cA.j2pcyadTGEp5Ci3p8mqveS7dCt44FrS','sorynsoo@gmail.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(8,'sorynsoo3','$2y$10$8DOiGse3C9mMacUoq0.Gl.jvCmOhuusWDfCD92MJBUBF3i7KWnTH6','saadad@gmail.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(9,'Seby','$2y$10$HJWkItASPS2edmRWE/Pbr.N0hm/uc0a/tl1QD7CyVFQ/kguuEL8TC','sebymarcu99@yahoo.com','[RNG]Seby','http://RNG-Servers.com','Fondator Romania New Generaiton.','9.jpeg','#0#41#34#42#43#44#47#48#49#50#52#55#54#56#61#60#59#58#67#68#70#71#',8,5,0,78,'#0#1#',2,'#0#1#2#','9.png'),(10,'polonic','$2y$10$KBvWyEzkPpf786x49mEL1.qe1NSEKHBZFfBgiA4lHBLuiCTvXsHXS','a.toderica.2013@gmail.com','polonic','Ex: http://www.rng-servers.com/','Maximum 100 words','10.jpeg','#0#42#49#',0,0,0,0,'#0#',0,'#0#',''),(11,'EAGame','$2y$10$1tcryn9gMVFoXAqCabgHdu9DHs1T2omaAWqGlCvNBEB4SXW4.HSk2','andreypopa24@yahoo.com','','','','','#0#42#41#',0,0,0,3,'#0#',0,'#0#',''),(12,'Piki','$2y$10$0rcu3v5/RwSfRCZWYA832uVoN.1AKnqAfBJ1kZwRxf5MsfgpBtAq2','amorkovu@yahoo.ro','','','','','#0#42#',1,0,1,0,'#0#',0,'#0#2#',''),(13,'Liviu','$2y$10$QjzVHk4SS/vmzzOwfKaZne0BPxIcTOG29nJQ3.BRxuUbzz.BxTpc6','bouruc.liviu2000@gmail.com','Liviu','Ex: https://www.facebook.com/yourbeautifulname','Ma gasiti pe comunitatea RNG cu nick-name-ul XGamer','13.jpeg','#0#42#47#43#44#49#67#59#60#',0,0,0,21,'#0#',1,'#0#',''),(14,'Eddu','$2y$10$WFLtBsFJNDbPaooBFiZ8n.8l89YxQUySF2jOvR82YCHqGSUWDedt.','edy_danyel@yahoo.com','','','','','#0#44#51#53#48#55#',1,0,1,6,'#0#',0,'#0#2#',''),(15,'VillaMan97','$2y$10$gIn3AA7zkhgbOg0dSj6tdeZxCyud61u9vSF7cOOi6HHtPy0k0hxwy','villa_man97@yahoo.com','Villa_Man','http://www.rng-servers.com/forums','Romania New Generation &raquo; Aim at your FUN!\r\nhttp://www.rng-servers.com','15.jpeg','#0#41#44#39#48#54#56#',1,1,0,18,'#0#',0,'#0#1#',''),(17,'pawn','$2y$10$dhAqvaP..ES34OEFiJPvNOaqZpL4rrPwamXaRwQ5QOaqbh9mE/TK.','pawnyq@yahoo.com','','','','','#0#34#37#47#52#51#54#',0,0,0,12,'#0#',0,'#0#',''),(16,'Roby','$2y$10$qw7Z5YhnXYcXkpIrQWGnEOLPyVDTfls.O8Lw9lLfAopo3HVOyd0ni','samp.theroby@yahoo.com','','','','','#0#38#61#60#59#58#',0,0,0,12,'#0#9#',0,'#0#',''),(18,'CocaCola','$2y$10$p.izpQHvQPOzXQTCZ6Bm.eAbbqzASKzDK05AB0wyw4307X0fOzTWa','jokker_flokker@yahoo.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(19,'Eremia123','$2y$10$IDBlu0tX/xwDssyVjsD9Wu7BV/VgEunOguNfAmxZ.96hlKvm5I8La','jokker_flokker@yahoo.com','','','','','#0#54#',0,0,0,3,'#0#',0,'#0#',''),(20,'Tony','$2y$10$XWowOCMgoNkFuuMgyMmRFOmk.onB9PjeX2Cm3hoQbtksIBZa9Tm9q','pamfil_tony@yahoo.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(21,'Andre','$2y$10$oiLo7C5bt2zyjA5zg11b/.cG731PB4VK8C8tKAr59xK95PfrOz7VC','ss_andre66@yahoo.com','','','','','#0#47#',0,0,0,0,'#0#',0,'#0#',''),(22,'Annaabiro','$2y$10$pV4PTBLCjDj0V6IKRcC2VuoxetJSilSS5zgXySIZiQE5f7VDKTioS','anna.biro@yahoo.com','','','','','#0#36#',0,0,0,3,'#0#',0,'#0#',''),(23,'Laurentiu','$2y$10$lDZDnjIH1GVT2T7cdeIateH47wbfCpMDI7VYcMoeGZYvqMDWVWVau','laurentiuconstantinpricop@yahoo.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(24,'Silver','$2y$10$Ml5wHXIe1bDFCa.W6O.Vv.bAuHOk7hOfpeyK9NY53IZoQo3zuZo.y','enescuflorian91@yahoo.com','Silver','','Maximum 100 words','24.png','#0#55#44#53#49#58#47#54#61#60#59#',0,0,0,21,'#0#',0,'#0#',''),(33,'alex','$2y$10$o7CVAeX7QmLH8urlXp/4P.hkj/.aD22Bq/G6ukH/n7RvTuB1TGnPm','sorynsoo@gmail.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#',''),(34,'Mitza','$2y$10$eBvBEVgnmL7xpvlU6E8Dx.HkkaXNFdsFC7JMF/07zeJkg6E2vkYN6','samp_theseby@yahoo.com','[RNG]Seby','http://RNG-Servers.com','Fondator Romania New Generation.','34.png','#0#',1,1,0,10,'#0#',0,'#0#1#',''),(32,'Andreea','$2y$10$G377MvxdSKngGs6N4LD27u3KUZVwBCgNJ5ilWAdHpSsYzlvJa1b/y','andreea_gabriela_1997@yahoo.com','','','','','#0#68#59#70#',1,0,0,0,'#0#1#',0,'#0#2#',''),(35,'Andrei','$2y$10$/wV3wAQEgrYeI1g9sLbCAuUhRH/dCdajF9gTONGnnoaXM8bZhSiq.','sada@yahoo.com','','','','','#0#',0,0,0,0,'#0#',0,'#0#','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-20  5:13:43
